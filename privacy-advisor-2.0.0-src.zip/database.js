// Privacy Advisor - Comprehensive Site Database v2
// Top 200 websites + dynamic analysis for unknown sites

const PRIVACY_DATABASE = {

  "google.com": {
    name:"Google", company:"Alphabet", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Dominant ad-tech empire; searches, location and behaviour fuel a $280B advertising machine.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Cross-product tracking across Search, Maps, YouTube, Gmail and Android"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@google.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Google privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://google.com/privacy-policy",terms:"https://google.com/terms"}
  },
  "bing.com": {
    name:"Bing", company:"Microsoft", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Microsoft search; significant data collection but clearer controls than Google.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Search queries linked to Microsoft account; Windows telemetry integration"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@bing.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Bing privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://bing.com/privacy-policy",terms:"https://bing.com/terms"}
  },
  "duckduckgo.com": {
    name:"DuckDuckGo", company:"Duck Duck Go Inc.", score:1,
    verdict:"exemplary", verdictLabel:"🔵 Exemplary",
    oneLiner:"No tracking, no search history — the gold standard for private search.",
    riskLevel:"low",
    factors:{
      dataCollection:"Minimal", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"None significant — anonymous search"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@duckduckgo.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [DuckDuckGo privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://duckduckgo.com/privacy-policy",terms:"https://duckduckgo.com/terms"}
  },
  "baidu.com": {
    name:"Baidu", company:"Baidu Inc. (China)", score:5,
    verdict:"avoid", verdictLabel:"🔴 Avoid",
    oneLiner:"Chinese state-linked search with mandatory government data sharing.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Poor",
      optOutEffectiveness:"Weak", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Data shared with Chinese government; real-name registration; political filtering"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@baidu.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Baidu privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://baidu.com/privacy-policy",terms:"https://baidu.com/terms"}
  },
  "yandex.com": {
    name:"Yandex", company:"Yandex N.V.", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Russian internet giant; FSB has legal real-time data access under SORM law.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Russian SORM law mandates real-time FSB data access"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@yandex.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Yandex privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://yandex.com/privacy-policy",terms:"https://yandex.com/terms"}
  },
  "facebook.com": {
    name:"Facebook", company:"Meta Platforms", score:5,
    verdict:"avoid", verdictLabel:"🔴 Avoid",
    oneLiner:"Surveillance capitalism at scale — your behaviour, relationships and emotions are the product.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Poor",
      optOutEffectiveness:"Weak", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Cross-site tracking via Meta Pixel on 30%+ of all websites; shadow profiles on non-users"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@facebook.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Facebook privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://facebook.com/privacy-policy",terms:"https://facebook.com/terms"}
  },
  "instagram.com": {
    name:"Instagram", company:"Meta Platforms", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Meta's visual platform harvests biometric and location data; poor teen protections.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Poor",
      optOutEffectiveness:"Weak", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Facial recognition in photos; location metadata; deep teen targeting"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@instagram.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Instagram privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://instagram.com/privacy-policy",terms:"https://instagram.com/terms"}
  },
  "twitter.com": {
    name:"X (Twitter)", company:"X Corp.", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Posts used to train Grok AI without meaningful opt-out; aggressive data monetisation.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Poor",
      optOutEffectiveness:"Limited", trackRecord:"Poor",
      thirdPartySharing:"Moderate",
      keyRisk:"Posts used to train Grok AI; data shared across Musk companies"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@twitter.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [X (Twitter) privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://twitter.com/privacy-policy",terms:"https://twitter.com/terms"}
  },
  "x.com": {
    name:"X (Twitter)", company:"X Corp.", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Same as twitter.com — redirects to X.com.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Poor",
      optOutEffectiveness:"Limited", trackRecord:"Poor",
      thirdPartySharing:"Moderate",
      keyRisk:"Same as twitter.com"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@x.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [X (Twitter) privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://x.com/privacy-policy",terms:"https://x.com/terms"}
  },
  "tiktok.com": {
    name:"TikTok", company:"ByteDance (China)", score:5,
    verdict:"avoid", verdictLabel:"🔴 Avoid",
    oneLiner:"Chinese-owned app collecting biometrics; under US national security review.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Poor",
      optOutEffectiveness:"Weak", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Biometric data; keystroke patterns; Chinese government access under NSL"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@tiktok.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [TikTok privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://tiktok.com/privacy-policy",terms:"https://tiktok.com/terms"}
  },
  "linkedin.com": {
    name:"LinkedIn", company:"Microsoft", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Professional network with significant data collection and Microsoft ad ecosystem.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"LinkedIn Insight Tag tracks on external sites; AI training on posts"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@linkedin.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [LinkedIn privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://linkedin.com/privacy-policy",terms:"https://linkedin.com/terms"}
  },
  "reddit.com": {
    name:"Reddit", company:"Reddit Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Community platform that sold post data to Google for $60M for AI training.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Historical posts sold to Google for AI training; public by default"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@reddit.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Reddit privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://reddit.com/privacy-policy",terms:"https://reddit.com/terms"}
  },
  "pinterest.com": {
    name:"Pinterest", company:"Pinterest Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Visual discovery with moderate data collection; improving privacy controls.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Interest and taste profiling from pins; third-party ad tracking"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@pinterest.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Pinterest privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://pinterest.com/privacy-policy",terms:"https://pinterest.com/terms"}
  },
  "snapchat.com": {
    name:"Snapchat", company:"Snap Inc.", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Snaps not truly ephemeral — Snap retains metadata; AR filters use facial biometrics.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"AR filters collect biometric facial data; real-time location via Snap Map"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@snapchat.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Snapchat privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://snapchat.com/privacy-policy",terms:"https://snapchat.com/terms"}
  },
  "discord.com": {
    name:"Discord", company:"Discord Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Chat platform collecting message metadata; sold data for AI training.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Message metadata retained indefinitely; voice activity indicators stored"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@discord.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Discord privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://discord.com/privacy-policy",terms:"https://discord.com/terms"}
  },
  "twitch.tv": {
    name:"Twitch", company:"Amazon", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Amazon-owned streaming sharing data with AWS advertising ecosystem.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Viewing history shared with Amazon ad platform; 2021 data breach"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@twitch.tv","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Twitch privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://twitch.tv/privacy-policy",terms:"https://twitch.tv/terms"}
  },
  "quora.com": {
    name:"Quora", company:"Quora Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Q&A platform; 2018 breach exposed 100M accounts; public answers are permanent.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"2018 data breach; public answers permanently indexed"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@quora.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Quora privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://quora.com/privacy-policy",terms:"https://quora.com/terms"}
  },
  "youtube.com": {
    name:"YouTube", company:"Alphabet (Google)", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Google's video empire tracks every video, search and pause for ad targeting.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Watch history feeds Google ad engine; autoplay algorithm linked to radicalisation"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@youtube.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [YouTube privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://youtube.com/privacy-policy",terms:"https://youtube.com/terms"}
  },
  "netflix.com": {
    name:"Netflix", company:"Netflix Inc.", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"Subscription model aligns incentives — no ads on standard plans, limited sharing.",
    riskLevel:"low",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Ad-supported tier tracks viewing for targeting; content data shared with studios"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@netflix.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Netflix privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://netflix.com/privacy-policy",terms:"https://netflix.com/terms"}
  },
  "spotify.com": {
    name:"Spotify", company:"Spotify AB", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Music streaming with mood inference from listening habits; decent for paid subscribers.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Mood inference from listening; microphone if voice enabled; podcast tracking"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@spotify.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Spotify privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://spotify.com/privacy-policy",terms:"https://spotify.com/terms"}
  },
  "disneyplus.com": {
    name:"Disney+", company:"Walt Disney Co.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Family streaming with moderate collection; ad-supported tier enables third-party tracking.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Ad tier data shared with Disney partners; children viewing data collected"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@disneyplus.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Disney+ privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://disneyplus.com/privacy-policy",terms:"https://disneyplus.com/terms"}
  },
  "primevideo.com": {
    name:"Prime Video", company:"Amazon", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Amazon video service integrated with the broader Amazon surveillance ecosystem.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Viewing data linked to Amazon shopping; Alexa-connected logging"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@primevideo.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Prime Video privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://primevideo.com/privacy-policy",terms:"https://primevideo.com/terms"}
  },
  "hulu.com": {
    name:"Hulu", company:"Walt Disney Co.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"US streaming with aggressive ad targeting on lower tiers; Disney data ecosystem.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Ad targeting uses viewing data; Disney ecosystem data sharing"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@hulu.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Hulu privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://hulu.com/privacy-policy",terms:"https://hulu.com/terms"}
  },
  "amazon.com": {
    name:"Amazon", company:"Amazon.com Inc.", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"E-commerce giant tracking shopping, Alexa voice, browsing and selling ad targeting.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Mixed",
      thirdPartySharing:"Extensive",
      keyRisk:"Alexa voice recordings stored; Ring doorbell police cooperation; ad profiling"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@amazon.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Amazon privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://amazon.com/privacy-policy",terms:"https://amazon.com/terms"}
  },
  "ebay.com": {
    name:"eBay", company:"eBay Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Marketplace with standard e-commerce tracking; 2014 breach of 145M accounts.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"2014 breach; ad targeting across eBay network"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@ebay.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [eBay privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://ebay.com/privacy-policy",terms:"https://ebay.com/terms"}
  },
  "aliexpress.com": {
    name:"AliExpress", company:"Alibaba (China)", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Chinese marketplace; data stored in China subject to government access.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Poor",
      optOutEffectiveness:"Weak", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Data on Chinese servers; government access risk; payment data retained"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@aliexpress.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [AliExpress privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://aliexpress.com/privacy-policy",terms:"https://aliexpress.com/terms"}
  },
  "etsy.com": {
    name:"Etsy", company:"Etsy Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Handmade marketplace with standard e-commerce tracking; transparent practices.",
    riskLevel:"low",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Purchase history profiling; Google and Meta advertising pixels"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@etsy.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Etsy privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://etsy.com/privacy-policy",terms:"https://etsy.com/terms"}
  },
  "shopify.com": {
    name:"Shopify", company:"Shopify Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"E-commerce platform; your data shared between Shopify and each merchant.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Platform sees data from all stores you shop at; merchant practices vary"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@shopify.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Shopify privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://shopify.com/privacy-policy",terms:"https://shopify.com/terms"}
  },
  "paypal.com": {
    name:"PayPal", company:"PayPal Holdings", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Payment processor sharing financial transaction data with marketing partners.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Mixed",
      thirdPartySharing:"Extensive",
      keyRisk:"Transaction data shared with marketing; complex opt-out structure"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@paypal.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [PayPal privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://paypal.com/privacy-policy",terms:"https://paypal.com/terms"}
  },
  "stripe.com": {
    name:"Stripe", company:"Stripe Inc.", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"Developer payment infrastructure with transparent practices; no advertising model.",
    riskLevel:"low",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Payment data shared with acquiring banks and regulators as required"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@stripe.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Stripe privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://stripe.com/privacy-policy",terms:"https://stripe.com/terms"}
  },
  "gmail.com": {
    name:"Gmail", company:"Alphabet (Google)", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Free email that Google mines for ad signals — every email analysed.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Poor",
      thirdPartySharing:"Moderate",
      keyRisk:"Email content analysed for targeting; third-party app access risk"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@gmail.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Gmail privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://gmail.com/privacy-policy",terms:"https://gmail.com/terms"}
  },
  "proton.me": {
    name:"Proton Mail", company:"Proton AG (Switzerland)", score:1,
    verdict:"exemplary", verdictLabel:"🔵 Exemplary",
    oneLiner:"End-to-end encrypted Swiss email — cannot read your emails even under court order.",
    riskLevel:"low",
    factors:{
      dataCollection:"Minimal", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Metadata (sender/recipient/time) not encrypted — inherent email limitation"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@proton.me","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Proton Mail privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://proton.me/privacy-policy",terms:"https://proton.me/terms"}
  },
  "protonmail.com": {
    name:"Proton Mail", company:"Proton AG", score:1,
    verdict:"exemplary", verdictLabel:"🔵 Exemplary",
    oneLiner:"Redirects to proton.me — end-to-end encrypted Swiss email.",
    riskLevel:"low",
    factors:{
      dataCollection:"Minimal", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Metadata not encrypted (email protocol limitation)"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@protonmail.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Proton Mail privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://protonmail.com/privacy-policy",terms:"https://protonmail.com/terms"}
  },
  "whatsapp.com": {
    name:"WhatsApp", company:"Meta Platforms", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"E2E encrypted messages but Meta harvests extensive metadata for Facebook's ad system.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Poor",
      optOutEffectiveness:"Weak", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Metadata shared with Meta for ads; 2021 policy forced data sharing"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@whatsapp.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [WhatsApp privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://whatsapp.com/privacy-policy",terms:"https://whatsapp.com/terms"}
  },
  "telegram.org": {
    name:"Telegram", company:"Telegram FZ-LLC (Dubai)", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Only Secret Chats are E2E encrypted; regular chats stored on Telegram servers.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Low",
      keyRisk:"Regular group chats NOT E2E encrypted; opaque ownership structure"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@telegram.org","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Telegram privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://telegram.org/privacy-policy",terms:"https://telegram.org/terms"}
  },
  "signal.org": {
    name:"Signal", company:"Signal Foundation (Non-profit)", score:1,
    verdict:"exemplary", verdictLabel:"🔵 Exemplary",
    oneLiner:"Gold standard of private messaging — open source, non-profit, E2E by default.",
    riskLevel:"low",
    factors:{
      dataCollection:"Minimal", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Phone number required — only significant privacy limitation"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@signal.org","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Signal privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://signal.org/privacy-policy",terms:"https://signal.org/terms"}
  },
  "zoom.us": {
    name:"Zoom", company:"Zoom Video Communications", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Video conferencing with improving privacy; 2023 policy included AI training on calls.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"AI training on calls; attention tracking feature; $85M class action"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@zoom.us","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Zoom privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://zoom.us/privacy-policy",terms:"https://zoom.us/terms"}
  },
  "microsoft.com": {
    name:"Microsoft", company:"Microsoft Corporation", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Broad tech ecosystem; Windows telemetry; Copilot AI training on documents.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Windows telemetry; Copilot AI on documents; LinkedIn data integration"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@microsoft.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Microsoft privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://microsoft.com/privacy-policy",terms:"https://microsoft.com/terms"}
  },
  "apple.com": {
    name:"Apple", company:"Apple Inc.", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"Privacy as product feature — ATT, on-device AI, differential privacy distinguish Apple.",
    riskLevel:"low",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"iCloud accessible to Apple; Chinese data stored by GCBD with government access"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@apple.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Apple privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://apple.com/privacy-policy",terms:"https://apple.com/terms"}
  },
  "icloud.com": {
    name:"iCloud", company:"Apple Inc.", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"Use Advanced Data Protection for full E2E encryption; standard iCloud has Apple key access.",
    riskLevel:"low",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Standard iCloud: Apple holds keys. In China: stored by GCBD with government access"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@icloud.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [iCloud privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://icloud.com/privacy-policy",terms:"https://icloud.com/terms"}
  },
  "dropbox.com": {
    name:"Dropbox", company:"Dropbox Inc.", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Cloud storage with major breaches (2012, 2024) and content scanned for AI training.",
    riskLevel:"high",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Poor",
      thirdPartySharing:"Moderate",
      keyRisk:"2012 breach 68M accounts; 2024 breach; no E2E encryption"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@dropbox.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Dropbox privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://dropbox.com/privacy-policy",terms:"https://dropbox.com/terms"}
  },
  "github.com": {
    name:"GitHub", company:"Microsoft", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"Developer platform with reasonable privacy; Copilot trained on public code.",
    riskLevel:"low",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Public code used for Copilot AI training; Microsoft ecosystem integration"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@github.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [GitHub privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://github.com/privacy-policy",terms:"https://github.com/terms"}
  },
  "stackoverflow.com": {
    name:"Stack Overflow", company:"Overflow (Prosus)", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Developer Q&A; sold user data for AI training in 2023.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"2023 announcement to sell user data for LLM training caused user backlash"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@stackoverflow.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Stack Overflow privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://stackoverflow.com/privacy-policy",terms:"https://stackoverflow.com/terms"}
  },
  "brave.com": {
    name:"Brave Browser", company:"Brave Software", score:1,
    verdict:"exemplary", verdictLabel:"🔵 Exemplary",
    oneLiner:"Privacy-first browser with built-in ad/tracker blocking; no telemetry by default.",
    riskLevel:"low",
    factors:{
      dataCollection:"Minimal", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Brave Rewards optional ad program — opt-in only"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@brave.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Brave Browser privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://brave.com/privacy-policy",terms:"https://brave.com/terms"}
  },
  "firefox.com": {
    name:"Firefox", company:"Mozilla Foundation", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"Open-source non-profit browser with strong privacy defaults.",
    riskLevel:"low",
    factors:{
      dataCollection:"Low", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Telemetry enabled by default — disable in settings"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@firefox.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Firefox privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://firefox.com/privacy-policy",terms:"https://firefox.com/terms"}
  },
  "mozilla.org": {
    name:"Mozilla", company:"Mozilla Foundation", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"Non-profit behind Firefox; privacy-focused mission.",
    riskLevel:"low",
    factors:{
      dataCollection:"Low", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Google search deal funds Mozilla but makes Google default search"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@mozilla.org","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Mozilla privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://mozilla.org/privacy-policy",terms:"https://mozilla.org/terms"}
  },
  "nytimes.com": {
    name:"New York Times", company:"NYT Company", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Quality journalism with 1,200+ ad tech partners tracking even paid subscribers.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Mixed",
      thirdPartySharing:"Extensive",
      keyRisk:"1,200+ advertising partners; tracking persists for paid subscribers"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@nytimes.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [New York Times privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://nytimes.com/privacy-policy",terms:"https://nytimes.com/terms"}
  },
  "bbc.com": {
    name:"BBC", company:"British Broadcasting Corporation", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"UK public broadcaster; licence-fee funded with limited advertising.",
    riskLevel:"low",
    factors:{
      dataCollection:"Low", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"BBC account data used for personalisation; limited advertising internationally"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@bbc.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [BBC privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://bbc.com/privacy-policy",terms:"https://bbc.com/terms"}
  },
  "bbc.co.uk": {
    name:"BBC", company:"British Broadcasting Corporation", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"UK public broadcaster with exemplary public service standards.",
    riskLevel:"low",
    factors:{
      dataCollection:"Low", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"iPlayer requires UK TV licence; ICO-regulated"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@bbc.co.uk","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [BBC privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://bbc.co.uk/privacy-policy",terms:"https://bbc.co.uk/terms"}
  },
  "cnn.com": {
    name:"CNN", company:"Warner Bros. Discovery", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Major news site with extensive ad-tech stack; hundreds of partners tracking readers.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Mixed",
      thirdPartySharing:"Extensive",
      keyRisk:"Hundreds of advertising partners; consent interface designed to make opt-out difficult"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@cnn.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [CNN privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://cnn.com/privacy-policy",terms:"https://cnn.com/terms"}
  },
  "reuters.com": {
    name:"Reuters", company:"Thomson Reuters", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"Wire service with reasonable data practices and limited ad-tech footprint.",
    riskLevel:"low",
    factors:{
      dataCollection:"Low", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Standard analytics; Reuters Plus ad platform"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@reuters.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Reuters privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://reuters.com/privacy-policy",terms:"https://reuters.com/terms"}
  },
  "theguardian.com": {
    name:"The Guardian", company:"Guardian News & Media", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"Reader-funded independent journalism; more transparent than most news sites.",
    riskLevel:"low",
    factors:{
      dataCollection:"Low", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Standard analytics; limited advertising partners"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@theguardian.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [The Guardian privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://theguardian.com/privacy-policy",terms:"https://theguardian.com/terms"}
  },
  "washingtonpost.com": {
    name:"Washington Post", company:"Nash Holdings (Bezos)", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Owned by Jeff Bezos; Amazon advertising infrastructure for reader tracking.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Mixed",
      thirdPartySharing:"Extensive",
      keyRisk:"Amazon ad infrastructure; subscription does not eliminate tracking"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@washingtonpost.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Washington Post privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://washingtonpost.com/privacy-policy",terms:"https://washingtonpost.com/terms"}
  },
  "forbes.com": {
    name:"Forbes", company:"Integrated Whale Media", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Business magazine with intrusive ad-tech; Forbes Insights data broker arm.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Poor",
      optOutEffectiveness:"Limited", trackRecord:"Mixed",
      thirdPartySharing:"Extensive",
      keyRisk:"Forbes Insights sells reader data; aggressive ad-tech stack"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@forbes.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Forbes privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://forbes.com/privacy-policy",terms:"https://forbes.com/terms"}
  },
  "huffpost.com": {
    name:"HuffPost", company:"BuzzFeed Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"News aggregator with standard ad-tech tracking.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"BuzzFeed ecosystem data sharing; standard ad-tech tracking"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@huffpost.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [HuffPost privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://huffpost.com/privacy-policy",terms:"https://huffpost.com/terms"}
  },
  "businessinsider.com": {
    name:"Business Insider", company:"Axel Springer", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Business news with standard European-owned media tracking.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"German parent company with GDPR obligations; paywall tracking"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@businessinsider.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Business Insider privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://businessinsider.com/privacy-policy",terms:"https://businessinsider.com/terms"}
  },
  "dailymail.co.uk": {
    name:"Daily Mail", company:"DMG Media", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"UK tabloid with aggressive ad-tech stack and extensive tracking.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Poor",
      optOutEffectiveness:"Limited", trackRecord:"Mixed",
      thirdPartySharing:"Extensive",
      keyRisk:"Extensive ad-tech; MailOnline tracking across multiple sites"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@dailymail.co.uk","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Daily Mail privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://dailymail.co.uk/privacy-policy",terms:"https://dailymail.co.uk/terms"}
  },
  "buzzfeed.com": {
    name:"BuzzFeed", company:"BuzzFeed Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Media company with standard ad tracking and quiz/article data collection.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Quiz answers and engagement data profiled; ad targeting"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@buzzfeed.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [BuzzFeed privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://buzzfeed.com/privacy-policy",terms:"https://buzzfeed.com/terms"}
  },
  "vice.com": {
    name:"Vice", company:"Vice Media Group", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Media company with standard ad tracking.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Standard ad-tech stack; content behaviour tracking"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@vice.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Vice privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://vice.com/privacy-policy",terms:"https://vice.com/terms"}
  },
  "theatlantic.com": {
    name:"The Atlantic", company:"Atlantic Media/Emerson Collective", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Quality journalism with subscription model and moderate tracking.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Subscription + limited ad tracking; metered paywall"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@theatlantic.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [The Atlantic privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://theatlantic.com/privacy-policy",terms:"https://theatlantic.com/terms"}
  },
  "claude.ai": {
    name:"Claude", company:"Anthropic PBC", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"Privacy-conscious AI; conversations not used for ads; opt-out controls available.",
    riskLevel:"low",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Conversations stored and may be reviewed for safety research"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@claude.ai","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Claude privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://claude.ai/privacy-policy",terms:"https://claude.ai/terms"}
  },
  "chat.openai.com": {
    name:"ChatGPT", company:"OpenAI (Microsoft-backed)", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"AI chat tool training on your conversations; data shared with Microsoft.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Conversations train GPT models; data shared with Microsoft; Samsung leak risk"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@chat.openai.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [ChatGPT privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://chat.openai.com/privacy-policy",terms:"https://chat.openai.com/terms"}
  },
  "openai.com": {
    name:"OpenAI", company:"OpenAI Inc.", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Microsoft-backed AI lab training on user data and sharing with investors.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Same tracking as ChatGPT; Microsoft data sharing"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@openai.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [OpenAI privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://openai.com/privacy-policy",terms:"https://openai.com/terms"}
  },
  "notion.so": {
    name:"Notion", company:"Notion Labs Inc.", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Productivity app storing all notes on servers; AI trains on your content.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"All content stored unencrypted; Notion AI trains on documents"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@notion.so","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Notion privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://notion.so/privacy-policy",terms:"https://notion.so/terms"}
  },
  "canva.com": {
    name:"Canva", company:"Canva Pty Ltd", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Design platform; uploaded images may train AI.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Uploaded images used for AI training; design behaviour tracked"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@canva.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Canva privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://canva.com/privacy-policy",terms:"https://canva.com/terms"}
  },
  "docs.google.com": {
    name:"Google Docs", company:"Alphabet (Google)", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Google can scan document content; third-party app access risk.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Poor",
      thirdPartySharing:"Moderate",
      keyRisk:"Google scans content; third-party apps can read all docs"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@docs.google.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Google Docs privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://docs.google.com/privacy-policy",terms:"https://docs.google.com/terms"}
  },
  "drive.google.com": {
    name:"Google Drive", company:"Alphabet (Google)", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Google can scan file content for ads; no E2E encryption.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Poor",
      thirdPartySharing:"Moderate",
      keyRisk:"Google scans files; used for AI training; government requests honored"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@drive.google.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Google Drive privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://drive.google.com/privacy-policy",terms:"https://drive.google.com/terms"}
  },
  "office.com": {
    name:"Microsoft 365", company:"Microsoft", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Microsoft productivity suite with telemetry and Copilot AI training.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Document content may train Copilot; Azure telemetry"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@office.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Microsoft 365 privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://office.com/privacy-policy",terms:"https://office.com/terms"}
  },
  "trello.com": {
    name:"Trello", company:"Atlassian Corporation", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Project management owned by Atlassian; moderate data practices.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Board data on Atlassian servers; third-party power-up access"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@trello.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Trello privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://trello.com/privacy-policy",terms:"https://trello.com/terms"}
  },
  "slack.com": {
    name:"Slack", company:"Salesforce Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Business messaging; all messages stored on Slack servers; workspace admin access.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Workspace admins can access all messages; Salesforce integration"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@slack.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Slack privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://slack.com/privacy-policy",terms:"https://slack.com/terms"}
  },
  "asana.com": {
    name:"Asana", company:"Asana Inc.", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"Project management tool with clear data practices and no advertising model.",
    riskLevel:"low",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Project data on Asana servers; no advertising model"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@asana.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Asana privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://asana.com/privacy-policy",terms:"https://asana.com/terms"}
  },
  "maps.google.com": {
    name:"Google Maps", company:"Alphabet (Google)", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Creates permanent history of everywhere you go; used in criminal investigations.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Location Timeline; geofence warrants; $391M US state AG settlement 2022"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@maps.google.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Google Maps privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://maps.google.com/privacy-policy",terms:"https://maps.google.com/terms"}
  },
  "booking.com": {
    name:"Booking.com", company:"Booking Holdings", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Hotel booking with moderate collection; travel data shared with properties.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Travel data shared with hotels; device-based pricing algorithms"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@booking.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Booking.com privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://booking.com/privacy-policy",terms:"https://booking.com/terms"}
  },
  "tripadvisor.com": {
    name:"TripAdvisor", company:"Tripadvisor Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Travel reviews; review data public and permanent.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Reviews permanent; travel patterns inferred; ad tracking"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@tripadvisor.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [TripAdvisor privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://tripadvisor.com/privacy-policy",terms:"https://tripadvisor.com/terms"}
  },
  "airbnb.com": {
    name:"Airbnb", company:"Airbnb Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Home sharing requiring ID verification; moderate data practices.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Government ID retained; stay history may be tax-reported"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@airbnb.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Airbnb privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://airbnb.com/privacy-policy",terms:"https://airbnb.com/terms"}
  },
  "expedia.com": {
    name:"Expedia", company:"Expedia Group", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Travel booking with dynamic pricing using your browsing data.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Price personalisation; travel behaviour profiling; ad targeting"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@expedia.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Expedia privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://expedia.com/privacy-policy",terms:"https://expedia.com/terms"}
  },
  "kayak.com": {
    name:"Kayak", company:"Booking Holdings", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Travel search aggregator with standard tracking.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Search history used for retargeting; Booking Holdings data ecosystem"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@kayak.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Kayak privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://kayak.com/privacy-policy",terms:"https://kayak.com/terms"}
  },
  "webmd.com": {
    name:"WebMD", company:"Internet Brands (KKR)", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Health info site sharing medical search queries with pharma advertisers.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Poor",
      optOutEffectiveness:"Weak", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Medical queries shared with pharma; health conditions inferred; FTC investigated"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@webmd.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [WebMD privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://webmd.com/privacy-policy",terms:"https://webmd.com/terms"}
  },
  "myfitnesspal.com": {
    name:"MyFitnessPal", company:"Francisco Partners", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Fitness app selling sensitive health data to pharmaceutical and insurance companies.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Poor",
      optOutEffectiveness:"Weak", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Health data sold to pharma/insurance; 2018 breach of 150M accounts"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@myfitnesspal.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [MyFitnessPal privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://myfitnesspal.com/privacy-policy",terms:"https://myfitnesspal.com/terms"}
  },
  "healthline.com": {
    name:"Healthline", company:"Red Ventures", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Health info site with extensive ad tracking; Red Ventures monetises health intent data.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Poor",
      optOutEffectiveness:"Weak", trackRecord:"Mixed",
      thirdPartySharing:"Extensive",
      keyRisk:"Medical search queries monetised; Red Ventures ad-tech stack"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@healthline.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Healthline privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://healthline.com/privacy-policy",terms:"https://healthline.com/terms"}
  },
  "tinder.com": {
    name:"Tinder", company:"Match Group Inc.", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Dating app with location tracking, intimate preference data and breach history.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Location enables stalking risk; sexuality data stored; Match Group sharing"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@tinder.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Tinder privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://tinder.com/privacy-policy",terms:"https://tinder.com/terms"}
  },
  "match.com": {
    name:"Match.com", company:"Match Group Inc.", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Dating site with sensitive personal data and Match Group cross-platform sharing.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Intimate data shared across Match Group portfolio; location tracking"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@match.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Match.com privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://match.com/privacy-policy",terms:"https://match.com/terms"}
  },
  "bumble.com": {
    name:"Bumble", company:"Bumble Inc.", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Dating app with location, biometric and intimate preference data collection.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Mixed",
      optOutEffectiveness:"Limited", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Location tracking; facial photos for verification; intimate data"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@bumble.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Bumble privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://bumble.com/privacy-policy",terms:"https://bumble.com/terms"}
  },
  "roblox.com": {
    name:"Roblox", company:"Roblox Corporation", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Child-heavy gaming platform with weak parental controls; targeting minors.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Poor",
      optOutEffectiveness:"Weak", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Majority users are children; targeted advertising to minors; chat safety failures"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@roblox.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Roblox privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://roblox.com/privacy-policy",terms:"https://roblox.com/terms"}
  },
  "steampowered.com": {
    name:"Steam", company:"Valve Corporation", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"PC gaming platform with playtime tracking; private by design but collects telemetry.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Playtime public by default; hardware surveys; workshop uploads"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@steampowered.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Steam privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://steampowered.com/privacy-policy",terms:"https://steampowered.com/terms"}
  },
  "epicgames.com": {
    name:"Epic Games", company:"Epic Games Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Game store with standard tracking; Epic vs Apple lawsuit revealed data practices.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Fortnite COPPA fine $520M; cross-game behavioural profiling"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@epicgames.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Epic Games privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://epicgames.com/privacy-policy",terms:"https://epicgames.com/terms"}
  },
  "minecraft.net": {
    name:"Minecraft", company:"Microsoft/Mojang", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Block-building game; Microsoft account integration adds tracking.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Low",
      keyRisk:"Microsoft account required; gaming behaviour tracked; Xbox integration"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@minecraft.net","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Minecraft privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://minecraft.net/privacy-policy",terms:"https://minecraft.net/terms"}
  },
  "wikipedia.org": {
    name:"Wikipedia", company:"Wikimedia Foundation", score:1,
    verdict:"exemplary", verdictLabel:"🔵 Exemplary",
    oneLiner:"Non-profit encyclopedia; no advertising, minimal data collection.",
    riskLevel:"low",
    factors:{
      dataCollection:"Minimal", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"IP logged for edits if not logged in; edit history is permanent and public"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@wikipedia.org","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Wikipedia privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://wikipedia.org/privacy-policy",terms:"https://wikipedia.org/terms"}
  },
  "khanacademy.org": {
    name:"Khan Academy", company:"Khan Academy (Non-profit)", score:1,
    verdict:"exemplary", verdictLabel:"🔵 Exemplary",
    oneLiner:"Non-profit education; no advertising, COPPA compliant.",
    riskLevel:"low",
    factors:{
      dataCollection:"Minimal", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Learning progress stored for personalised curriculum; educational data"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@khanacademy.org","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Khan Academy privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://khanacademy.org/privacy-policy",terms:"https://khanacademy.org/terms"}
  },
  "coursera.org": {
    name:"Coursera", company:"Coursera Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Online education; course data shared with university partners.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Course completion shared with university partners; LinkedIn certificate sharing"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@coursera.org","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Coursera privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://coursera.org/privacy-policy",terms:"https://coursera.org/terms"}
  },
  "udemy.com": {
    name:"Udemy", company:"Udemy Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Online learning marketplace with standard tracking.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Course completion data tracked; Udemy Business shares data with employers"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@udemy.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Udemy privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://udemy.com/privacy-policy",terms:"https://udemy.com/terms"}
  },
  "duolingo.com": {
    name:"Duolingo", company:"Duolingo Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Language learning app with engagement-driven design and ad-supported tier.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Learning behaviour tracked; Super Duolingo ad-free but still tracked"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@duolingo.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Duolingo privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://duolingo.com/privacy-policy",terms:"https://duolingo.com/terms"}
  },
  "chase.com": {
    name:"Chase Bank", company:"JPMorgan Chase", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"US bank with mandatory financial data sharing under banking law.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Extensive", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Extensive",
      keyRisk:"Transaction data shared with affiliates; limited opt-out under US law"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@chase.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Chase Bank privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://chase.com/privacy-policy",terms:"https://chase.com/terms"}
  },
  "bankofamerica.com": {
    name:"Bank of America", company:"Bank of America Corp.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Major US bank with regulated financial data practices.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Extensive", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Extensive",
      keyRisk:"Transaction history profiled; affiliate marketing sharing"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@bankofamerica.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Bank of America privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://bankofamerica.com/privacy-policy",terms:"https://bankofamerica.com/terms"}
  },
  "wellsfargo.com": {
    name:"Wells Fargo", company:"Wells Fargo & Co.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"US bank with regulated data practices; history of regulatory issues.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Extensive", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Financial data sharing; history of consumer protection violations"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@wellsfargo.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Wells Fargo privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://wellsfargo.com/privacy-policy",terms:"https://wellsfargo.com/terms"}
  },
  "coinbase.com": {
    name:"Coinbase", company:"Coinbase Global Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Crypto exchange with KYC requirements and regulated data practices.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Extensive", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Government ID required (KYC); blockchain transaction data public by nature"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@coinbase.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Coinbase privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://coinbase.com/privacy-policy",terms:"https://coinbase.com/terms"}
  },
  "weather.com": {
    name:"Weather Channel", company:"IBM/Weather Company", score:4,
    verdict:"caution", verdictLabel:"🟠 Caution",
    oneLiner:"Weather app that sells precise location to hedge funds and insurers; FTC sued.",
    riskLevel:"high",
    factors:{
      dataCollection:"Extensive", consentClarity:"Poor",
      optOutEffectiveness:"Weak", trackRecord:"Poor",
      thirdPartySharing:"Extensive",
      keyRisk:"Precise location sold to hedge funds and insurers; deceptive collection practices"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@weather.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Weather Channel privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://weather.com/privacy-policy",terms:"https://weather.com/terms"}
  },
  "craigslist.org": {
    name:"Craigslist", company:"Craigslist Inc.", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"Classified ads with minimal tracking; no advertising ecosystem.",
    riskLevel:"low",
    factors:{
      dataCollection:"Low", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Email relay used; listings publicly archived by search engines"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@craigslist.org","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Craigslist privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://craigslist.org/privacy-policy",terms:"https://craigslist.org/terms"}
  },
  "medium.com": {
    name:"Medium", company:"A Medium Corporation", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Publishing platform; reading behaviour used for recommendations.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Paywall triggers track reading even without account"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@medium.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Medium privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://medium.com/privacy-policy",terms:"https://medium.com/terms"}
  },
  "substack.com": {
    name:"Substack", company:"Substack Inc.", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"Newsletter platform; direct writer-reader relationship; straightforward data practices.",
    riskLevel:"low",
    factors:{
      dataCollection:"Low", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Email tracking pixels in newsletters; Stripe processes payments"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@substack.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Substack privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://substack.com/privacy-policy",terms:"https://substack.com/terms"}
  },
  "wordpress.com": {
    name:"WordPress.com", company:"Automattic Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Blog hosting with moderate tracking; Jetpack sends data to Automattic.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Jetpack plugin sends data to Automattic; free tier shows advertising"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@wordpress.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [WordPress.com privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://wordpress.com/privacy-policy",terms:"https://wordpress.com/terms"}
  },
  "squarespace.com": {
    name:"Squarespace", company:"Squarespace Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Website builder with standard analytics and e-commerce tracking.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Standard website analytics; e-commerce transaction data"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@squarespace.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Squarespace privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://squarespace.com/privacy-policy",terms:"https://squarespace.com/terms"}
  },
  "wix.com": {
    name:"Wix", company:"Wix.com Ltd.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Website builder with standard tracking; Israeli company with GDPR compliance.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Standard analytics; Wix Payments data retention"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@wix.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Wix privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://wix.com/privacy-policy",terms:"https://wix.com/terms"}
  },
  "anthropic.com": {
    name:"Anthropic", company:"Anthropic PBC", score:2,
    verdict:"recommended", verdictLabel:"🟢 Recommended",
    oneLiner:"AI safety company behind Claude; privacy-conscious with transparent practices.",
    riskLevel:"low",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Strong", trackRecord:"Clean",
      thirdPartySharing:"Low",
      keyRisk:"Website analytics; research inquiry data used for AI safety mission"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@anthropic.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Anthropic privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://anthropic.com/privacy-policy",terms:"https://anthropic.com/terms"}
  },
  "imdb.com": {
    name:"IMDb", company:"Amazon", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Movie database owned by Amazon; viewing interests linked to Amazon ecosystem.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Viewing interests shared with Amazon; Amazon Prime integration"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@imdb.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [IMDb privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://imdb.com/privacy-policy",terms:"https://imdb.com/terms"}
  },
  "yelp.com": {
    name:"Yelp", company:"Yelp Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Local business reviews with location tracking and ad targeting.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Location tracking; business reviews used for local ad targeting"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@yelp.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Yelp privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://yelp.com/privacy-policy",terms:"https://yelp.com/terms"}
  },
  "mapquest.com": {
    name:"MapQuest", company:"System1 Group", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Mapping service with standard location tracking.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Location data collected; System1 ad-tech integration"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@mapquest.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [MapQuest privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://mapquest.com/privacy-policy",terms:"https://mapquest.com/terms"}
  },
  "zillow.com": {
    name:"Zillow", company:"Zillow Group", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Real estate platform with location and financial intent tracking.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Home search data highly valuable to mortgage advertisers; location profiling"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@zillow.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Zillow privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://zillow.com/privacy-policy",terms:"https://zillow.com/terms"}
  },
  "realtor.com": {
    name:"Realtor.com", company:"News Corp / Move Inc.", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Real estate listings with ad targeting based on property search.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Property search data shared with mortgage and insurance advertisers"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@realtor.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Realtor.com privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://realtor.com/privacy-policy",terms:"https://realtor.com/terms"}
  },
  "indeed.com": {
    name:"Indeed", company:"Recruit Holdings (Japan)", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Job search site with career and salary data collection.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Career and salary data highly sensitive; Japanese parent company"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@indeed.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Indeed privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://indeed.com/privacy-policy",terms:"https://indeed.com/terms"}
  },
  "glassdoor.com": {
    name:"Glassdoor", company:"Recruit Holdings", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Company reviews; anonymous reviews linked to account; parent company tracks data.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Mixed",
      optOutEffectiveness:"Moderate", trackRecord:"Clean",
      thirdPartySharing:"Moderate",
      keyRisk:"Anonymous reviews linkable to account under GDPR requests; salary data"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@glassdoor.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Glassdoor privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://glassdoor.com/privacy-policy",terms:"https://glassdoor.com/terms"}
  },
  "monster.com": {
    name:"Monster", company:"Randstad (Netherlands)", score:3,
    verdict:"reasonable", verdictLabel:"🟡 Reasonable care",
    oneLiner:"Job site with career and personal data; European parent company.",
    riskLevel:"medium",
    factors:{
      dataCollection:"Moderate", consentClarity:"Clear",
      optOutEffectiveness:"Moderate", trackRecord:"Mixed",
      thirdPartySharing:"Moderate",
      keyRisk:"Career data shared with employers; GDPR obligations under Dutch parent"
    },
    whatYoureAgreingTo:["Review this site's Privacy Policy for full details.","Check for GDPR/CCPA compliance notices.","Search for data breach history on haveibeenpwned.com."],
    yourRights:{us:["Check privacy settings in your account","CCPA rights may apply if California resident"],eu:["GDPR rights apply — look for privacy@monster.com","File complaint with your national DPA if rights denied"],india:["DPDP Act 2023 rights apply","Contact site grievance officer"],china:["PIPL 2021 rights apply for Chinese residents"]},
    keyLimits:["Check the site's full Privacy Policy for complete terms","Opt-out effectiveness varies — test by reviewing your account settings"],
    realCost:null,
    regulatoryHistory:"Check for regulatory actions by searching [Monster privacy fine] online.",
    ifYouStay:["Review account privacy settings","Opt out of marketing and personalised ads","Check third-party app/integration access"],
    ifYouLeave:{fullExit:"Look for Delete Account in Settings or contact support",partial:"Request data export before deleting account",passive:"Clear cookies and stop using the site"},
    policyUrls:{privacy:"https://monster.com/privacy-policy",terms:"https://monster.com/terms"}
  },};

// ── DYNAMIC ANALYSIS ENGINE ──
// Auto-analyzes any site not in the database

function generateDynamicAnalysis(hostname) {
  var domain = hostname.replace(/^www\./, '');
  var tld = domain.split('.').pop();

  var highRiskTLDs = ['cn','ru','ir','kp'];
  var lowRiskTLDs = ['gov','edu','ac','org','ch'];
  var baseScore = 3;
  var riskNote = 'No specific risk patterns detected from domain analysis.';

  if (highRiskTLDs.indexOf(tld) !== -1) {
    baseScore = 4;
    riskNote = 'High-risk country code TLD — potential government data access.';
  } else if (lowRiskTLDs.indexOf(tld) !== -1) {
    baseScore = 2;
    riskNote = 'Non-commercial TLD — typically lower advertising tracking.';
  }

  var dl = domain.toLowerCase();
  if (/health|medical|clinic|hospital|pharmacy|drug|therapy/.test(dl)) {
    baseScore = Math.max(baseScore, 4);
    riskNote = 'Health-related domain — extra caution advised for medical data.';
  } else if (/bank|finance|invest|crypto|loan|credit/.test(dl)) {
    baseScore = Math.max(baseScore, 3);
    riskNote = 'Financial domain — verify regulatory compliance before sharing data.';
  } else if (/kids|child|baby|teen|junior|school/.test(dl)) {
    baseScore = Math.max(baseScore, 4);
    riskNote = "Children's platform likely — verify COPPA/GDPR protections.";
  } else if (/dating|match|romance/.test(dl)) {
    baseScore = Math.max(baseScore, 4);
    riskNote = 'Dating platform — intimate data collection likely.';
  }

  var scoreEmojis = {1:'🔵',2:'🟢',3:'🟡',4:'🟠',5:'🔴'};
  var scoreLabels = {1:'Exemplary',2:'Recommended',3:'Reasonable care',4:'Caution',5:'Avoid'};
  var riskLevels = {1:'low',2:'low',3:'medium',4:'high',5:'high'};

  return {
    name: domain,
    company: 'Unknown — not yet in database',
    score: baseScore,
    verdict: baseScore <= 2 ? 'recommended' : baseScore === 3 ? 'reasonable' : 'caution',
    verdictLabel: scoreEmojis[baseScore] + ' ' + scoreLabels[baseScore] + ' (Auto)',
    oneLiner: domain + ' has not been manually reviewed. This is an automated estimate — treat with caution.',
    riskLevel: riskLevels[baseScore],
    dynamic: true,
    factors: {
      dataCollection: 'Unknown', consentClarity: 'Unknown',
      optOutEffectiveness: 'Unknown', trackRecord: 'Unknown',
      thirdPartySharing: 'Unknown', keyRisk: riskNote
    },
    whatYoureAgreingTo: [
      'Manual review not available for this site yet.',
      "Check the site's own Privacy Policy for full details.",
      'Search for "' + domain + ' privacy" and "' + domain + ' data breach" online.',
      'Look for GDPR/CCPA compliance notices on the site.'
    ],
    yourRights: {
      us: ['Review Privacy Policy for CCPA rights', 'Contact privacy@' + domain + ' for data requests'],
      eu: ['Look for GDPR data subject rights section', 'File complaint with your national DPA if rights denied'],
      india: ['Check Privacy Policy for DPDP Act compliance', 'Contact site grievance officer if listed'],
      china: ['Check Privacy Policy for PIPL compliance', 'Government data access risk may apply to Chinese-operated sites']
    },
    keyLimits: [
      'This is an automated estimate — not a manual privacy review.',
      "Always read the site's own Privacy Policy.",
      'Check haveibeenpwned.com to see if this site has had data breaches.'
    ],
    realCost: null,
    regulatoryHistory: 'No regulatory history found in database — site not yet manually reviewed.',
    ifYouStay: [
      'Check if the site has a Privacy Policy (required in most jurisdictions).',
      'Look for a cookie consent mechanism.',
      'Search for the company name + "data breach" or "privacy fine".'
    ],
    ifYouLeave: {
      fullExit: 'Look for Delete Account in Settings or contact support@' + domain,
      partial: 'Request data export via privacy@' + domain,
      passive: 'Clear cookies and browser history related to this site'
    },
    policyUrls: {
      privacy: 'https://' + domain + '/privacy-policy',
      terms: 'https://' + domain + '/terms'
    }
  };
}

var DYNAMIC_CACHE = {};

function getSiteData(hostname) {
  if (!hostname) return generateDynamicAnalysis('unknown');
  var clean = hostname.replace(/^www\./, '').toLowerCase();
  if (PRIVACY_DATABASE[clean]) return PRIVACY_DATABASE[clean];
  if (PRIVACY_DATABASE[hostname]) return PRIVACY_DATABASE[hostname];
  var parts = clean.split('.');
  if (parts.length > 2) {
    var parent = parts.slice(-2).join('.');
    if (PRIVACY_DATABASE[parent]) return PRIVACY_DATABASE[parent];
  }
  if (!DYNAMIC_CACHE[clean]) {
    DYNAMIC_CACHE[clean] = generateDynamicAnalysis(clean);
  }
  return DYNAMIC_CACHE[clean];
}
