// Privacy Advisor - Background Script (Firefox-first)
// database.js is loaded first in manifest scripts array

var api = (typeof browser !== 'undefined') ? browser : chrome;

var BADGE_COLORS = {0:'#94a3b8',1:'#3b82f6',2:'#22c55e',3:'#eab308',4:'#f97316',5:'#ef4444'};

function storageGet(keys) {
  if (typeof browser !== 'undefined') return browser.storage.local.get(keys);
  return new Promise(function(r){ chrome.storage.local.get(keys, r); });
}
function storageSet(data) {
  if (typeof browser !== 'undefined') return browser.storage.local.set(data);
  return new Promise(function(r){ chrome.storage.local.set(data, r); });
}

// Track which tabs we've already shown advisory for this session
var shownThisSession = {};

api.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (changeInfo.status !== 'complete' || !tab.url) return;

  var url;
  try { url = new URL(tab.url); } catch(e) { return; }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    api.action.setBadgeText({tabId: tabId, text: ''});
    return;
  }

  var hostname = url.hostname;
  var siteData = getSiteData(hostname);
  var color = BADGE_COLORS[siteData.score] || BADGE_COLORS[0];

  // Set badge
  api.action.setBadgeBackgroundColor({tabId: tabId, color: color});
  api.action.setBadgeText({tabId: tabId, text: '●'});

  // Cache result
  var cacheKey = 'site_' + hostname.replace(/\./g,'_');
  var cacheObj = {};
  cacheObj[cacheKey] = {data: siteData, timestamp: Date.now()};
  storageSet(cacheObj);

  // Show advisory popup — once per hostname per tab per session
  var sessionKey = tabId + '_' + hostname;
  if (shownThisSession[sessionKey]) return;
  shownThisSession[sessionKey] = true;

  storageGet(['onboardingComplete']).then(function(result) {
    if (!result.onboardingComplete) return; // Don't show before setup

    api.windows.create({
      url: api.runtime.getURL('advisory.html') + '?hostname=' + encodeURIComponent(hostname),
      type: 'popup',
      width: 440,
      height: 280,
      focused: true
    });
  }).catch(function(e){ console.log('Advisory error:', e); });
});

// Clean up session memory when tab closes
api.tabs.onRemoved.addListener(function(tabId) {
  Object.keys(shownThisSession).forEach(function(key) {
    if (key.startsWith(tabId + '_')) delete shownThisSession[key];
  });
});

api.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.type === 'GET_SITE_DATA') {
    sendResponse({data: getSiteData(message.hostname), hostname: message.hostname});
  }
  return true;
});
