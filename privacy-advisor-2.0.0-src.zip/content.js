// Privacy Advisor - Content Script (Firefox-first)
(function () {
  if (window.__privacyAdvisorLoaded) return;
  window.__privacyAdvisorLoaded = true;
  var api = typeof browser !== 'undefined' ? browser : chrome;
  try {
    api.runtime.sendMessage({ type: 'PAGE_LOADED', hostname: window.location.hostname });
  } catch(e) {}
})();
