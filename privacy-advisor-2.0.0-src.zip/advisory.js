// advisory.js — uses safe DOM methods (no innerHTML) to pass Firefox store review

var SCORE_COLORS = {0:'#94a3b8',1:'#3b82f6',2:'#22c55e',3:'#eab308',4:'#f97316',5:'#ef4444'};

var params = new URLSearchParams(window.location.search);
var hostname = params.get('hostname') || '';
var data = getSiteData(hostname);
var color = SCORE_COLORS[data.score] || SCORE_COLORS[0];
var riskClass = {low:'risk-low',medium:'risk-medium',high:'risk-high'}[data.riskLevel] || 'risk-unknown';
var content = document.getElementById('content');

function el(tag, attrs, text) {
  var e = document.createElement(tag);
  if (attrs) Object.keys(attrs).forEach(function(k){ e.setAttribute(k, attrs[k]); });
  if (text !== undefined) e.textContent = text;
  return e;
}

if (data.verdict === 'unknown') {
  var wrap = el('div', {class:'not-found'});
  var icon = el('div', {class:'icon'});
  icon.textContent = '🔍';
  var title = el('strong', {style:'color:#e2e8f0'}, hostname || 'Unknown site');
  var br1 = document.createElement('br');
  var br2 = document.createElement('br');
  var desc = document.createTextNode('This site is not in the database yet. Check its privacy policy before sharing personal info.');
  wrap.appendChild(icon);
  wrap.appendChild(title);
  wrap.appendChild(br1);
  wrap.appendChild(br2);
  wrap.appendChild(desc);
  content.appendChild(wrap);

  var row = el('div', {class:'action-row'});
  var btn = el('button', {class:'btn btn-muted', id:'closeBtn2'}, 'Close');
  row.appendChild(btn);
  content.appendChild(row);

} else {
  // Site row
  var siteRow = el('div', {class:'site-row'});
  var dot = el('div', {class:'score-dot'});
  dot.style.background = color;
  var name = el('span', {class:'site-name'}, data.name || hostname);
  var host = el('span', {class:'site-hostname'}, hostname);
  siteRow.appendChild(dot);
  siteRow.appendChild(name);
  siteRow.appendChild(host);
  content.appendChild(siteRow);

  // Verdict box
  var box = el('div', {class:'verdict-box'});
  var vLabel = el('div', {class:'verdict-label'}, 'Privacy verdict');
  var vText  = el('div', {class:'verdict-text'},  data.oneLiner);
  var chip   = el('span', {class:'risk-chip ' + riskClass}, data.verdictLabel);
  box.appendChild(vLabel);
  box.appendChild(vText);
  box.appendChild(chip);
  content.appendChild(box);

  // Action row
  var actionRow = el('div', {class:'action-row'});
  var detailBtn  = el('button', {class:'btn btn-primary', id:'detailBtn'},  'Full analysis');
  var dismissBtn = el('button', {class:'btn btn-muted',   id:'closeBtn2'}, 'Dismiss');
  actionRow.appendChild(detailBtn);
  actionRow.appendChild(dismissBtn);
  content.appendChild(actionRow);
}

// Close button (top ✕)
document.getElementById('closeBtn').addEventListener('click', function() { window.close(); });

// Close/Dismiss button
var cb2 = document.getElementById('closeBtn2');
if (cb2) cb2.addEventListener('click', function() { window.close(); });

// Full analysis button
var detBtn = document.getElementById('detailBtn');
if (detBtn) {
  detBtn.addEventListener('click', function() {
    var api = typeof browser !== 'undefined' ? browser : chrome;
    api.tabs.create({ url: api.runtime.getURL('popup.html') + '?hostname=' + encodeURIComponent(hostname) });
    window.close();
  });
}
