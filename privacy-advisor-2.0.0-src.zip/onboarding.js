// onboarding.js — external file (Firefox CSP blocks inline scripts)

document.querySelectorAll('.options').forEach(function(group) {
  group.querySelectorAll('.option').forEach(function(opt) {
    opt.addEventListener('click', function() {
      group.querySelectorAll('.option').forEach(function(o){ o.classList.remove('selected'); });
      opt.classList.add('selected');
      var radio = opt.querySelector('input[type="radio"]');
      if (radio) radio.checked = true;
    });
  });
});

document.getElementById('saveBtn').addEventListener('click', function() {
  var btn = document.getElementById('saveBtn');
  var statusMsg = document.getElementById('statusMsg');

  var ageEl    = document.querySelector('#ageOptions .selected');
  var regionEl = document.querySelector('#regionOptions .selected');
  var age    = ageEl    ? ageEl.getAttribute('data-value')    : 'adult';
  var region = regionEl ? regionEl.getAttribute('data-value') : 'us';

  statusMsg.textContent = 'Saving…';

  var saveData = { userProfile: {age:age, region:region}, onboardingComplete: true };

  function onSaved() {
    btn.textContent = '✅ Saved! You can close this tab.';
    btn.classList.add('saved');
    statusMsg.textContent = 'Profile saved: ' + age + ' · ' + region.toUpperCase();
    setTimeout(function(){ try { window.close(); } catch(e){} }, 1500);
  }
  function onError(e) {
    statusMsg.textContent = '⚠️ Error: ' + (e && e.message ? e.message : String(e));
    btn.textContent = 'Try again';
  }

  try {
    if (typeof browser !== 'undefined' && browser.storage) {
      browser.storage.local.set(saveData).then(onSaved).catch(onError);
    } else if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.set(saveData, function() {
        if (chrome.runtime.lastError) { onError(chrome.runtime.lastError); } else { onSaved(); }
      });
    } else {
      onError(new Error('No storage API. Make sure extension is loaded via about:debugging.'));
    }
  } catch(e) { onError(e); }
});
