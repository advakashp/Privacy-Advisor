// popup.js — Firefox-first, no innerHTML (safe DOM only, passes Firefox store review)

function storageGet(keys) {
  if (typeof browser !== 'undefined') return browser.storage.local.get(keys);
  return new Promise(function(r){ chrome.storage.local.get(keys, r); });
}
function storageSet(data) {
  if (typeof browser !== 'undefined') return browser.storage.local.set(data);
  return new Promise(function(r){ chrome.storage.local.set(data, r); });
}
function tabsQuery(q) {
  if (typeof browser !== 'undefined') return browser.tabs.query(q);
  return new Promise(function(r){ chrome.tabs.query(q, r); });
}
function openTab(url) {
  var api = typeof browser !== 'undefined' ? browser : chrome;
  api.tabs.create({ url: url });
}

// Safe element creation helper
function el(tag, cls, text) {
  var e = document.createElement(tag);
  if (cls)  e.className   = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}
function attr(e, k, v) { e.setAttribute(k, v); return e; }

var SCORE_COLORS    = {0:'#94a3b8',1:'#3b82f6',2:'#22c55e',3:'#eab308',4:'#f97316',5:'#ef4444'};
var SCORE_POSITIONS = {0:'10%',1:'10%',2:'30%',3:'50%',4:'70%',5:'90%'};

function getPillClass(v) {
  if (!v) return 'pill-unknown';
  var map = {low:'pill-low',minimal:'pill-minimal',clear:'pill-clear',strong:'pill-strong',clean:'pill-clean',
             moderate:'pill-moderate',mixed:'pill-mixed',limited:'pill-limited',
             extensive:'pill-extensive',poor:'pill-poor',weak:'pill-weak'};
  return map[v.toLowerCase().trim()] || 'pill-unknown';
}

// ── Build unknown state ──
function buildUnknown(container) {
  var wrap = el('div','unknown-state');
  wrap.appendChild(el('div','unknown-emoji','🔍'));
  wrap.appendChild(el('div','unknown-title','Site not in database'));
  wrap.appendChild(el('div','unknown-desc','No analysis available. Check the site\'s own privacy policy before sharing personal information.'));
  container.appendChild(wrap);
}

// ── Build expandable section ──
function buildSection(id, icon, title, buildBody) {
  var sec = el('div','expand-section'); sec.id = id;
  var btn = el('button','expand-trigger'); attr(btn,'data-target',id);
  var lbl = el('span','expand-trigger-label', icon + ' ' + title);
  var arrow = el('span','expand-trigger-arrow','▼');
  btn.appendChild(lbl); btn.appendChild(arrow);
  var body = el('div','expand-body');
  buildBody(body);
  sec.appendChild(btn); sec.appendChild(body);
  return sec;
}

// ── Build bullet list ──
function buildBullets(container, items) {
  if (!items || !items.length) {
    container.appendChild(el('p',null,'No data available.')).style.cssText='font-size:0.76rem;color:var(--muted);padding-top:0.4rem';
    return;
  }
  var ul = el('ul','bullet-list');
  items.forEach(function(b){ ul.appendChild(el('li',null,b)); });
  container.appendChild(ul);
}

// ── Build rights ──
function buildRights(container, rights, region) {
  var r = (rights && rights[region]) ? rights[region] : (rights && rights.us ? rights.us : []);
  var labels = {us:'🇺🇸 United States',eu:'🇪🇺 EU / UK',india:'🇮🇳 India',china:'🇨🇳 China'};
  container.appendChild(el('div','rights-region-label', labels[region] || region));
  buildBullets(container, r.length ? r : null);
}

// ── Build leave table ──
function buildLeaveTable(container, leave) {
  if (!leave) return;
  var rows = [];
  if (leave.fullExit) rows.push({o:'Full exit',d:leave.fullExit});
  if (leave.partial)  rows.push({o:'Partial',  d:leave.partial});
  if (leave.passive)  rows.push({o:'Passive',  d:leave.passive});
  if (!rows.length) return;
  var tbl = el('table','inline-table');
  var thead = document.createElement('thead');
  var hr = document.createElement('tr');
  hr.appendChild(el('th',null,'Option')); hr.appendChild(el('th',null,'Description'));
  thead.appendChild(hr); tbl.appendChild(thead);
  var tbody = document.createElement('tbody');
  rows.forEach(function(row){
    var tr = document.createElement('tr');
    tr.appendChild(el('td',null,row.o)); tr.appendChild(el('td',null,row.d));
    tbody.appendChild(tr);
  });
  tbl.appendChild(tbody);
  container.appendChild(tbl);
}

// ── Main content builder ──
function buildContent(mainDiv, data, profile) {
  mainDiv.textContent = ''; // clear

  if (data.verdict === 'unknown') { buildUnknown(mainDiv); return; }

  var region = (profile && profile.region) || 'us';
  var age    = (profile && profile.age)    || 'adult';
  var color  = SCORE_COLORS[data.score]    || SCORE_COLORS[0];
  var pos    = SCORE_POSITIONS[data.score] || '10%';
  var riskClass = {low:'risk-low',medium:'risk-medium',high:'risk-high'}[data.riskLevel] || 'risk-unknown';

  // ── Score bar ──
  var scoreSection = el('div','score-section');
  var track = el('div','score-bar-track');
  var marker = el('div','score-bar-marker');
  marker.style.cssText = 'left:'+pos+';background:'+color;
  track.appendChild(marker);
  scoreSection.appendChild(track);
  var labels = el('div','score-bar-labels');
  ['🔵','🟢','🟡','🟠','🔴'].forEach(function(s){ labels.appendChild(el('span',null,s)); });
  scoreSection.appendChild(labels);
  mainDiv.appendChild(scoreSection);

  // ── Age note ──
  if (age === 'child') {
    var note = el('div',null);
    note.style.cssText='background:#fef3c7;border:1px solid #fcd34d;border-radius:8px;padding:0.5rem 0.75rem;margin:0.75rem 1rem 0;font-size:0.74rem;color:#92400e;';
    note.textContent = '👋 Parent note: Child user — COPPA protections highlighted.';
    mainDiv.appendChild(note);
  } else if (age === 'teen') {
    var note2 = el('div',null);
    note2.style.cssText='background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:0.5rem 0.75rem;margin:0.75rem 1rem 0;font-size:0.74rem;color:#1e40af;';
    note2.textContent = '🧑 Teen user: Some services have weaker protections for users 13–17.';
    mainDiv.appendChild(note2);
  }

  // ── Verdict ──
  var verdictSection = el('div','verdict-section');
  var vHeader = el('div','verdict-header');
  var vBadge  = el('div','verdict-badge', (data.verdictLabel||'').split(' ')[0]);
  var vBody   = el('div',null);
  vBody.appendChild(el('div','verdict-label', data.verdictLabel));
  vBody.appendChild(el('div','verdict-oneliner', data.oneLiner));
  var chip = el('span','risk-chip '+riskClass, 'Risk: '+(data.riskLevel ? data.riskLevel.charAt(0).toUpperCase()+data.riskLevel.slice(1) : 'Unknown'));
  vBody.appendChild(chip);
  vHeader.appendChild(vBadge); vHeader.appendChild(vBody);
  verdictSection.appendChild(vHeader);
  mainDiv.appendChild(verdictSection);

  mainDiv.appendChild(el('div','divider'));

  // ── Factors table ──
  var factorsSection = el('div','factors-section');
  factorsSection.appendChild(el('div','section-label','Factor breakdown'));
  var tbl = el('table','factors-table');
  var rows = [
    ['Data collection',       data.factors.dataCollection],
    ['Consent clarity',       data.factors.consentClarity],
    ['Opt-out effectiveness', data.factors.optOutEffectiveness],
    ['Track record',          data.factors.trackRecord],
    ['Third-party sharing',   data.factors.thirdPartySharing],
  ];
  rows.forEach(function(row){
    var tr = document.createElement('tr');
    tr.appendChild(el('td',null,row[0]));
    var td2 = document.createElement('td');
    var pill = el('span','rating-pill '+getPillClass(row[1]), row[1]||'Unknown');
    td2.appendChild(pill); tr.appendChild(td2); tbl.appendChild(tr);
  });
  // Key risk row
  var krTr = el('tr',null); krTr.className='key-risk-row';
  krTr.appendChild(el('td',null,'⚠️ Key risk'));
  krTr.appendChild(el('td',null, data.factors.keyRisk||'None'));
  tbl.appendChild(krTr);
  factorsSection.appendChild(tbl);
  mainDiv.appendChild(factorsSection);

  // ── Expandable sections ──
  mainDiv.appendChild(buildSection('sec-agreeing','📝',"What you're agreeing to",function(b){ buildBullets(b, data.whatYoureAgreingTo); }));
  mainDiv.appendChild(buildSection('sec-rights',  '⚖️','Your rights',            function(b){ buildRights(b, data.yourRights, region); }));
  mainDiv.appendChild(buildSection('sec-limits',  '🚧','Key limits',             function(b){ buildBullets(b, data.keyLimits); }));
  if (data.realCost) {
    mainDiv.appendChild(buildSection('sec-cost','💰','The real cost',function(b){
      var box = el('div','real-cost-box', data.realCost);
      b.appendChild(box);
    }));
  }
  mainDiv.appendChild(buildSection('sec-stay', '🛡️','If you stay',  function(b){ buildBullets(b, data.ifYouStay); }));
  mainDiv.appendChild(buildSection('sec-leave','🚪','If you leave', function(b){ buildLeaveTable(b, data.ifYouLeave); }));
  mainDiv.appendChild(buildSection('sec-reg',  '📋','Regulatory history', function(b){
    b.appendChild(el('p','reg-history', data.regulatoryHistory || 'No major regulatory actions on record.'));
  }));

  // ── Footer ──
  var footer = el('div','footer');
  if (data.policyUrls) {
    var links = el('div','policy-links');
    if (data.policyUrls.privacy) {
      var a1 = el('a','policy-link policy-ext-link','📄 Privacy Policy ↗');
      attr(a1,'href',data.policyUrls.privacy); links.appendChild(a1);
    }
    if (data.policyUrls.terms) {
      var a2 = el('a','policy-link policy-ext-link','📋 Terms ↗');
      attr(a2,'href',data.policyUrls.terms); links.appendChild(a2);
    }
    footer.appendChild(links);
  }
  footer.appendChild(el('p','disclaimer-text','⚠️ Not legal advice. Policies change; consult a professional for consequential decisions.'));
  mainDiv.appendChild(footer);

  // ── Expand/collapse handlers ──
  mainDiv.querySelectorAll('.expand-trigger').forEach(function(btn){
    btn.addEventListener('click',function(){
      var sec = document.getElementById(btn.getAttribute('data-target'));
      if (sec) sec.classList.toggle('open');
    });
  });

  // ── External link handlers ──
  mainDiv.querySelectorAll('.policy-ext-link').forEach(function(link){
    link.addEventListener('click',function(e){
      e.preventDefault(); openTab(link.getAttribute('href'));
    });
  });
}

// ── Init ──
function init() {
  storageGet(['onboardingComplete','userProfile']).then(function(stored) {
    if (!stored.onboardingComplete) {
      var api = typeof browser !== 'undefined' ? browser : chrome;
      api.tabs.create({ url: api.runtime.getURL('onboarding.html') });
      window.close(); return;
    }

    var profile = stored.userProfile || {age:'adult',region:'us'};
    var ageEl    = document.getElementById('profileAge');
    var regionEl = document.getElementById('profileRegion');
    if (ageEl)    ageEl.value    = profile.age;
    if (regionEl) regionEl.value = profile.region;

    var params   = new URLSearchParams(window.location.search);
    var paramHost = params.get('hostname');

    tabsQuery({active:true,currentWindow:true}).then(function(tabs) {
      var hostname = paramHost || '';
      if (!hostname && tabs[0] && tabs[0].url) {
        try { hostname = new URL(tabs[0].url).hostname; } catch(e) {}
      }
      var hostnameEl = document.getElementById('hostnameDisplay');
      if (hostnameEl) hostnameEl.textContent = hostname.replace(/^www\./,'') || '—';

      var mainDiv = document.getElementById('mainContent');
      buildContent(mainDiv, getSiteData(hostname), profile);
    });
  });
}

document.getElementById('settingsToggle').addEventListener('click',function(){
  document.getElementById('profilePanel').classList.toggle('visible');
});

document.getElementById('profileSave').addEventListener('click',function(){
  var age    = document.getElementById('profileAge').value;
  var region = document.getElementById('profileRegion').value;
  storageSet({userProfile:{age:age,region:region}}).then(function(){
    document.getElementById('profilePanel').classList.remove('visible');
    init();
  });
});

init();
